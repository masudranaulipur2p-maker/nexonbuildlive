/* ==========================================================
   iDoRenos — interactions
   ========================================================== */
(function () {
  'use strict';

  /* ---- sticky nav + reading progress ---- */
  const nav = document.getElementById('nav');
  const progress = document.getElementById('progress');

  function onScroll() {
    nav.classList.toggle('scrolled', window.scrollY > 40);
    const h = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = (h > 0 ? (window.scrollY / h) * 100 : 0) + '%';
  }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  /* ---- mobile menu ---- */
  const burger = document.getElementById('burger');
  const mobileMenu = document.getElementById('mobileMenu');
  burger.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('open');
    burger.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', String(open));
  });
  mobileMenu.querySelectorAll('a').forEach((a) =>
    a.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      burger.classList.remove('open');
      burger.setAttribute('aria-expanded', 'false');
    })
  );

  /* ---- reveal on scroll, with a light stagger ---- */
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry, i) => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const delay = (el.dataset.delay ? Number(el.dataset.delay) : i * 60);
        setTimeout(() => el.classList.add('in'), delay);
        io.unobserve(el);
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -70px 0px' }
  );
  document.querySelectorAll('.reveal').forEach((el) => io.observe(el));

  /* ---- gallery cards get a subtle pointer tilt ---- */
  const canHover = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  if (canHover) document.querySelectorAll('.g img, .ig-card img').forEach((img) => {
    const card = img.parentElement;
    card.addEventListener('pointermove', (e) => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      img.style.transform = `scale(1.07) translate(${x * -8}px, ${y * -8}px)`;
    });
    card.addEventListener('pointerleave', () => {
      img.style.transform = '';
    });
  });

  /* ---- smooth anchor scroll with fixed-nav offset ---- */
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if (!id || id.length < 2) return;
      const target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 72;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

  /* ---- close the mobile menu on resize to desktop ---- */
  window.addEventListener('resize', () => {
    if (window.innerWidth > 1180 && mobileMenu.classList.contains('open')) {
      mobileMenu.classList.remove('open');
      burger.classList.remove('open');
      burger.setAttribute('aria-expanded', 'false');
    }
  });

  /* ---- FAQ: keep one open at a time ---- */
  const acc = document.querySelectorAll('.acc details');
  acc.forEach((d) =>
    d.addEventListener('toggle', () => {
      if (d.open) acc.forEach((o) => { if (o !== d) o.open = false; });
    })
  );

  /* ---- highlight the section you're in ---- */
  const links = [...document.querySelectorAll('.nav-links a')];
  const sections = links
    .map((l) => document.querySelector(l.getAttribute('href')))
    .filter(Boolean);

  const spy = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((l) =>
          l.classList.toggle('active', l.getAttribute('href') === '#' + entry.target.id)
        );
      });
    },
    { threshold: 0.25, rootMargin: '-20% 0px -55% 0px' }
  );
  sections.forEach((s) => spy.observe(s));
})();
